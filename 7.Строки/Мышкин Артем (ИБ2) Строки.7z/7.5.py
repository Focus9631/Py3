print(max(input().split(), key=len))
