S=input()
S1=(S[round(len(S)-(len(S)//2)):])
S2=(S[:(round(len(S)-len(S)//2))])
print(S1,S2)

