s=input()
n=s.count('.')
print(n+1)
