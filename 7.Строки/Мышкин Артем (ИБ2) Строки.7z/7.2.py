s=input();
n=s.find(' ')
print(s[:n])
